# Word Hurdle Puzzle

Samostatné zadanie 08, vytvorené podľa kódu zo seminára.

## Spustenie

Archív obsahuje požadované zdroje lib/ + pubspec.yaml. V rozbalenom priečinku vygenerujte platformové súbory Flutteru a spustite hru:

```sh
flutter create --project-name word_hurdle_puzzle --platforms=android,ios,web .
flutter pub get
flutter run
```

Generované platformové priečinky nie sú súčasťou odovzdávaných zdrojov. V pôvodnom projekte flutter_homeworks je tá istá aplikácia uložená v lib/homeworks/08_word_hurdle/ a spúšťa sa cez flutter run -t lib/homeworks/08_word_hurdle/main.dart.

## Pravidlá

Uhádnite päťpísmenové anglické slovo na najviac šesť pokusov. Písmená zadávajte klávesnicou na obrazovke, DELETE vymaže posledný znak, SUBMIT overí slovo v slovníku english_words. Neúplné a neplatné slovo nespotrebuje pokus.

Farby zodpovedajú semináru: svetlé políčko = písmeno sa nachádza v cieľovom slove kdekoľvek, modrosivé políčko = písmeno sa v slove nenachádza. Neprítomné písmená sú na klávesnici červené. Výhra vyžaduje presnú zhodu celého slova. Play Again a ikona obnovenia volajú reset(). Quit zatvorí dialóg; ďalšiu hru spustíte ikonou obnovenia.

## Overenie

```sh
flutter analyze
flutter test
```

Balík prešiel analýzou bez chýb a 15 testami (8 testov provider-a a 7 testov používateľského rozhrania). Testy zahŕňajú výhru na šiesty pokus, prehru, neplatný vstup, reset a rozloženie na výšku aj na šírku. Stav spravuje ChangeNotifier/Provider bez setState().
